// We are initializing a router object from Express Router
const express = require("express");
const router = express.Router();
const homeController = require("../controllers/home");

// Display Home Page
router.get("/home", homeController.displayHome);

// Share thre router with others
// CommonJS Syntax
module.exports = router;
